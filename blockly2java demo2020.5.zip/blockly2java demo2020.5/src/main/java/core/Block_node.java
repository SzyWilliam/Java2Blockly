package core;

public interface Block_node {
    String toJavaCode();
    String toXML();
}
